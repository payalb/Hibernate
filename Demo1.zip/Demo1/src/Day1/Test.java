package Day1;
 public class Test {

    

      public static void main(String[] args) {

        

        //=============================================================================================

        //byte.

        //=============================================================================================

        

        //CREATE.--------------------------------------------------------------------------------------

        byte    value    =  65;                            //Decimal.     Implicit conversion from int.

                value    =  0101;                          //Octal.       Implicit conversion from int.

                value    =  0x41;                          //Hexadecimal. Implicit conversion from int.

             

                value    = Byte.parseByte("65"        );   //Decimal     since default base is 10.

                value    = Byte.parseByte("1000001", 2);   //Binary      since base is set to   2.

                value    = Byte.parseByte("101"    , 8);   //Octal       since base is set to   8.

                value    = Byte.parseByte("41"     ,16);   //Hexadecimal since base is set to  16.     

    

        //CONVERT TO.----------------------------------------------------------------------------------

        boolean convert1 = (value == 1) ;        //True only if left byte argument is 1.   

        char    convert2 = (char)  value;        //Excplicit conversion since not all char fit into.  

        short   convert3 = (short) value;        //Implicit conversion since all byte fit into short. 

        int     convert4 =         value;        //Implicit conversion since all byte fit into int.   

        long    convert5 =         value;        //Implicit conversion since all byte fit into long.  

        float   convert6 =         value;        //Implicit conversion since all byte fit into long:65.0 

        double  convert7 =         value;        //Implicit conversion since all byte fit into long:65.0 

        String  convert8 = String.valueOf(value);//Explicit conversion to String object.

                convert8 =  ""  +  value;        //Implicit ocnversion while concatenating.

    

        //DISPLAY.-------------------------------------------------------------------------------------

        System.out.println(value);

        System.out.println(Byte.toString(value));

                

        //=============================================================================================

        //Byte.

        //=============================================================================================

                

        //CREATE.--------------------------------------------------------------------------------------

        Byte    object   = new Byte      (value);          //byte argument.

                object   = new Byte      ("65" );          //Decimal.

      

                object   = Byte.valueOf  (value       );   //byte argument.         

                object   = Byte.valueOf  ("65"        );   //Decimal     since default base is 10.

                object   = Byte.valueOf  ("1000001", 2);   //Binary      since base is set to   2.

                object   = Byte.valueOf  ("101"    , 8);   //Octal       since base is set to   8.

                object   = Byte.valueOf  ("41"     ,16);   //Hexadecimal since base is set to  16.

    

        //CONVERT TO.-----------------------------------------------------------------------------------

        byte    primitive= object.byteValue();  

        String  string   = object.toString();       

                  

        //DISPLAY.-------------------------------------------------------------------------------------

        System.out.println(object);

        System.out.println(object.toString());

    

      }

    

    }



