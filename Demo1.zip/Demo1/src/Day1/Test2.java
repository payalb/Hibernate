package Day1;


class Test12{
	
	private static Test12 obj;//= new Test12();
	
	 Test12(){
		super();
	}
	
	public static Test12 getInstance(){
		
		if(obj==null){
			return new Test12();
		}
	 return obj;
 }
	@Override
	public Test12 clone(){
		return this;
	}
}

public class Test2 extends Test12{
	public static void main(String args[]){
		Test12 obj= Test12.getInstance();
		//super.getInstance();
	}
}