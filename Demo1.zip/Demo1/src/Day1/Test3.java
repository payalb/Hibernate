package Day1;

public class Test3 {
	
	public static void main(String args[]){
		//int, byte, short, long: 4, 1 (-128 to 127) , 2, 8: whole values
		//first bit: signed bit, 0 -> +ve, 1 -> -ve (2s complement form)
		//float, double
		//char
		//boolean
		
		//byte x= 65738;
		//float f= 123.456;
		
		//int[] a,b;
		int []a, b[];
		//b = {1,3};
		//b= new int[5];
		//int[] arr= new int[]{1,2,3,4};
		
		Number[] n= new Number[10];
		n[0]= 2;
		System.out.println(n.length);
		int ch= 'c';
		char[] c= new char[3];
		c[0]= 1;
		c[1]= 'a';
		//int[] arr1= c;
		int[][] arr2= new int[4][5];
		System.out.println(arr2[3].length);
		System.out.println(arr2.length);
		Test3 obj= new Test3();
		obj.add(1,2);
		obj.add(1,2,3,4);
		obj.add(2.3F, 3,4,5,6,7,2);
		long x=10l;
		float y= 12.3f;
		float z = x+y;
	}
	
/*	public void add(int x, int y){
		System.out.println("In 1");
	}
	*/
	public void add( float s, int... x){
		System.out.println("In 2");
	}
	
/*	public void add(int x, int... y){
		System.out.println("In 3");
	}
*/
}
