package Day1;

 public class Test4 extends Xmple{
	
	 public static void main(String[] args){
		 System.out.println("Hello World");
	 }
}


//java Test4

 class Xmple{
	
 public static void main(String[] args){
		 System.out.println(args[1]);
	 }
	
}
 
 //javac Xmple.java
 //java Xmple
 //java Xmple hello string 123