package Day1;

public class Test5Operators {
	
	public static void main(String args[]){
		
	int x=10, y=20;
	int z= (x<y? 40:50);
	// condition(boolean)? true: false ternary/ conditional
	System.out.println(z);
	}

	
}
