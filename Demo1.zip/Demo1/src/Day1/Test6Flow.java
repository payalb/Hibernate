package Day1;

public class Test6Flow {
	public static void main(String args[]){
		Test6Flow obj= new Test6Flow();
		int[] arr= new int[5];
		int u= 6;
		for(int x=0; x<arr.length; x++){
			arr[x]=x;
		}
		
		for(int x: arr){
			System.out.println(arr[x]);
		}
	}
}
