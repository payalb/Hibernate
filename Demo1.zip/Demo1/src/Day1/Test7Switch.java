package Day1;

public class Test7Switch {

	public static void main(String args[]){
		int x=5;
		//x=0;
		switch(x){
		default:
			System.out.println("default!");
		
		case 0:
			System.out.println("0");

			
		}
		/*if(true){
			
		}else*/
		for(x+=3, System.out.println("hi"); x<20; x+=5){
			System.out.println("hello"+ x);
		}
		/*while(true){
		//while(1){
			System.out.println("hi1");
		}
		*/
		/*while(false){
			
		}*/
		
		
	}
}
