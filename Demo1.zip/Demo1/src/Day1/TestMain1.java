package Day1;

public class TestMain1 {
	
	int ai5_$;// number, alphabets, _, $
	int b_$, t6, f;//with numbers u cannot start
	/*public static  void main(String ar[]){
	
		System.out.println("In main1"); 
		numeric 					char	boolean
		integral(byte 1, short 2, int 4, long 8)	floating(float 4, double 8)
		
		byte b= 4;
		
		
		
	}*/	
	
	

	long a= 32367324434343L;
	String ss="sdsff 4365jdhfdsh";
	byte z=1;
	int c=z;
	boolean d= true;
	char ch= 'a';//(0 to 65535) 2 bytes
	long i= 4543774757L;
	double x= 34.2548784547;
	float s= 474.44F;
	byte b=(byte) 128;
	public static  void main(){
		
		System.out.println("In main3"); 
		main(5);
		
	}	
	
	public static  void main(int ar){
		int[] idd;
		System.out.println("In main1"); 
		class1.main();
		int i= 5*6;
		idd= new int[ar];
		idd[0]= 1;
		idd[1]=3;
		idd[4]=3;
		//idd[5]=4;
		System.out.println(idd.length);
		int[][] a= {{1,2},{3,4}};
		int[][] b= new int[2][3];
		
		System.out.println(b[1][0]);
		b[1][0]=5;
		
		System.out.println(b[1][2]);//0
		
		int[][]a2= {{2,3,4},{3,4,5}};
		System.out.println(a2[1][2]);
	}	
}


//public class class1{
class class1{	
	
	public static  void main(String... ar){
		
		System.out.println("In main2"); 
		
		
	}	
	
/*	public static  void main(String[] ar){
		
		System.out.println("In main2"); 
		
		
	}*/	
}

