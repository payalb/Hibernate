package Day2;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.Stack;

import Day1.Test2;

public class Date extends Test2{
	
	public static void main(String args[]){
		Stack a= new Stack<String>();
		a.push("1");		
		a.push(3l);
		a.push("hello");		
		Iterator it= a.iterator();
		it.remove();
		while(it.hasNext()){
			it.next();
			it.remove();			
		}
	}

}

