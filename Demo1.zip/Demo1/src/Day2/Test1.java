package Day2;

class Test1 {
	public static void main(String args[]){
		System.out.println("A");
	}

}

class B {
	public static void main(String args[]){
		System.out.println("B");
	}

}

class C {
	public static void main(String args[]){
		System.out.println("c");
	}

}

class D {
	
}
