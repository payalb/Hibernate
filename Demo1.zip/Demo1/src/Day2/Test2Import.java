package Day2;

import java.util.Date;
import Day1.Test4;

public class Test2Import {	

	public static void main(String[] args) {
		
		Date d= new Date();
		Test1 obj= new Test1();
		Test4 obj1= new Test4();
		
	}

}


