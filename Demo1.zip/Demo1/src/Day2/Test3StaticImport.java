package Day2;

import static java.lang.Math.*;
import static java.lang.Integer.MAX_VALUE;
import static java.lang.Byte.*;

public class Test3StaticImport {
	
	public static int MAX_VALUE=1;
	public static void main(String args[]){
		System.out.println(Math.PI);
		System.out.println(PI);
		System.out.println(sin(12.3));
		System.out.println(MAX_VALUE);
	}

}
