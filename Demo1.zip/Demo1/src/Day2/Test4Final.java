package Day2;

public class Test4Final extends Final1{

	public static void main(String[] args) {
	print();
print1();
	}
/*	public  static void print(){
		System.out.println("hi"+ "A");
	}*/
	
/*	public  void print(){
		System.out.println("hi"+ "A");
	}*/
	
	//@Override
	public static void print1(){
		System.out.println("hi"+ "B");
	}
}


class Final1{
	public final static void print(){
		System.out.println("hi"+ "A");
	}
	
	public static void print1(){//try removing static from this method
		System.out.println("hi"+ "A");
	}
}