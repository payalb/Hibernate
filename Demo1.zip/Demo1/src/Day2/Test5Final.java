package Day2;

public class Test5Final  {

}


 final class Final2{
	 int x=5;
	 
	 public void add( int y){ //by default final
		 x++;				//not final
		 System.out.println(x+y);
	 }
	
}