package Day2;

public class Test6Abstract {

	public static void main(String[] args) {
		

	}

}
