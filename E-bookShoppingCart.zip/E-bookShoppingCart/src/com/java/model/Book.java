package com.java.model;


//Book table should have following columns in db.
public class Book {

	private int id;
	private String title;
	private String author;
	private float price;
	private int quantityAvailable;
	
//@TODO  Add hibernate annotations and getters setters so as to be able to fetch
	//book record corresponding to author/ title from the database. 

}
