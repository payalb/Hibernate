package com.java.model;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class DatabaseUtil {

	private static SessionFactory sf = null;

	// @TODO create session factory and getSession should successfully return
	// the session.

	public static Session getSession() {
		return sf.openSession();
	}

}
