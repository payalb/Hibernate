package com.java.model;



//Should be used to store order details in db.
public class Order {

private int id;
private String customerName;
private String customerEmail;
private String customerPh;
private int quantityOrdered;
private Book book;
}
