package com.java.model;


public class OrderDaoImpl implements OrderDao {
	

	@Override
	public void placeOrder(Order order){
		//@TODO write code to save the order object in db.
	}
	
	
	@Override
	public Order getOrderDetails(int order_id){
		//@TODO wrote code to get order details from db based on the order Id
		return null;
	}
	
	
}
