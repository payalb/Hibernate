package com.java.exception;

public class NotFoundException extends RuntimeException {


	private static final long serialVersionUID = 3816705382791344086L;

}
