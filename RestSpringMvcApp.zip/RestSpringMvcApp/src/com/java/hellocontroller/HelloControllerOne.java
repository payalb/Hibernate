package com.java.hellocontroller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import com.java.dao.HelloDao;
import com.java.dao.MyObject;
import com.java.exception.NotFoundException;
import com.java.model.MyList;


 @RestController 
 @RequestMapping("/hello")
public class HelloControllerOne {
 
	 @Autowired
	 HelloDao dao;
	 
	 @RequestMapping(method=RequestMethod.GET)
	 @ResponseBody
	String get(){
		 MyList<MyObject> list= new MyList<MyObject>();
		 list.addAll(dao.getList());
		 return list.toString();		 
	 }
	 
	 @RequestMapping(value="/{word}",method=RequestMethod.GET)
	 @ResponseBody
	 MyObject get(@PathVariable("word") String word){
		 MyObject obj= dao.getObject(word);
		 return obj;		 
	 }
	 
	 @RequestMapping(method=RequestMethod.POST)
	 @ResponseStatus(HttpStatus.MOVED_PERMANENTLY)
	 /*
	  * Default status: ok
	  * Request body mapped to MyObject
	  */
	 void post(@RequestBody MyObject obj, WebRequest req, HttpServletResponse resp){
		 dao.addObject(obj);
		 resp.addHeader("Location", req.getContextPath());
		 
	 }
	 
	 
	 @RequestMapping(value="/{word}", method=RequestMethod.POST)
	 @ResponseBody
	 MyObject get1(@PathVariable("word") String word){
		 MyObject obj= dao.getObject(word);		
		 return obj;
	 }
	 
	 /*
	  * Handle NotFoundException exceptions for this controller
	  */
	 @ExceptionHandler(NotFoundException.class)
	 @ResponseStatus(value=HttpStatus.NOT_FOUND, reason="Object not found")
	 void handleNotFound(NotFoundException ex){
		 
	 }
	 
	 
	 
	 
}