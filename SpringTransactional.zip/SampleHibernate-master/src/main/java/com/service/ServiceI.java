package com.service;

import java.util.List;

import com.models.Student;

public interface ServiceI {


	public void add(Student s1);
	

	public List<Student> getAll();

}
