package com.blog.samples.boot.exception;

public class CustomerNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 2468434988680850339L;	
}
